/**
 * A Lambda function that returns a static string
 */
// exports.helloFromLambdaHandler = async () => {
//     // If you change this message, you will need to change hello-from-lambda.test.js
//     const message = 'Hello from Lambda!';

//     // All log statements are written to CloudWatch
//     console.info(`${message}`);
    
//     return message;
// }
    const aws = require('aws-sdk');
    const sharp = require("sharp");
    aws.config.update({ region: "ap-northeast-2" })
    const s3 = new aws.S3();
    require('dotenv').config(); //dotenv 추가 
// s3 - sqs 
    exports.helloFromLambdaHandler = async (event, context) => {
    console.log(JSON.stringify(event)) // 
// s3 sqs
    //const s3Sqs = JSON.parse(event.Records[0].body)
    //console.log(context)
    const region = encodeURIComponent(event.Records[0].awsRegion)
    const bucketName = encodeURIComponent(event.Records[0].s3.bucket.name)
    const jpgFile = encodeURIComponent(event.Records[0].s3.object.key)
    const targetBucketName = encodeURIComponent("photo-bucket-image-seize")
    const Arn = encodeURIComponent("arn:aws:sns:ap-northeast-2:307420834314:event-sns")
    // 원본 버킷으로부터 파일 읽기
    const s3Object = await s3.getObject({
        Bucket: bucketName,
        Key: jpgFile
    }).promise()
    
    // 이미지 리사이즈, sharp 라이브러리가 필요합니다.
    const data = await sharp(s3Object.Body)
        .resize(200)
        .jpeg({ mozjpeg: true })
        .toBuffer()
    
    // 대상 버킷으로 파일 쓰기
    const result = await s3.putObject({
        Bucket: targetBucketName, 
        Key: jpgFile,
        ContentType: 'image/jpeg',
        Body: data,
        ACL: 'public-read'
    }).promise()

    // SNS 메세지 전달
    const message = {
        urlMessage: "링크: " + `https://${process.env.Bucket}.s3.${region}.amazonaws.com/${jpgFile}`,
        Subject: "Thumbnail URL ARRIVAL",
        snsArn: Arn
    }
    
    const sns = new AWS.SNS(region)
    await sns.publish(message).promise();



    return 'Hello from Lambda!';
}